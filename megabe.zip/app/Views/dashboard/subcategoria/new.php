
<?= view("dashboard/partials/_form-error"); ?>
<form action="create" method="POST" enctype="multipart/form-data">
<?= view("dashboard/subcategoria/_form",['textButton' => 'Guardar']); ?>
</form>