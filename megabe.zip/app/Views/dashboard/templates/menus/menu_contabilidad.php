
          <li><a class="nav-link scrollto active" href="/comprobante">Comprobante</a></li>
          <li><a class="nav-link scrollto" href="/conta">Contabilidad</a></li>
          <li><a class="nav-link scrollto" href="/reportes_contabilidad">reportes</a></li>

