
          <li><a class="nav-link scrollto active" href="/#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="/administracion/ver_pedidos">Confirmar Pagos</a></li>
          <li><a class="nav-link scrollto" href="/#portfolio">Categorias</a></li>
          <li><a class="nav-link scrollto" href="/administracion/armar_pedido"><span>Armar Pedido</span></a></li>