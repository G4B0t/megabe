
          <li><a class="nav-link scrollto active" href="/entrega_pedido">Entregas</a></li>
          <li><a class="nav-link scrollto" href="/transferencias">Transferencias</a></li>
          <li><a class="nav-link scrollto" href="/ingresos_items">Ingresos Productos</a></li>
          <li><a class="nav-link scrollto " href="/egresos_items">Egresos Productos</a></li>
          <li><a class="nav-link scrollto" href="/reportes_almacenes">Reportes</a></li>

