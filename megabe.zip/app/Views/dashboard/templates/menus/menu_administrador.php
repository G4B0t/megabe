
          <li><a class="nav-link scrollto active" href="/item">Productos</a></li>
          <li><a class="nav-link scrollto" href="/empleado">Empleados</a></li>
          <li><a class="nav-link scrollto" href="/cliente">Clientes</a></li>
          <li><a class="nav-link scrollto " href="/categoria">Categorias</a></li>
          <li><a class="nav-link scrollto" href="/subcategoria">Sub Categorias</a></li>
          <li><a class="nav-link scrollto" href="/marca">Marcas</a></li>
