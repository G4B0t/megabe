-- --------------------------------------------------------
-- Host:                         localhost
-- Versión del servidor:         5.7.24 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando estructura para tabla megabe.almacen
CREATE TABLE IF NOT EXISTS `almacen` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `direccion` varchar(100) NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `latitud` double DEFAULT NULL,
  `longitud` double DEFAULT NULL,
  `foto` varchar(100) DEFAULT '',
  `estado_sql` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.almacen: ~1 rows (aproximadamente)
DELETE FROM `almacen`;
/*!40000 ALTER TABLE `almacen` DISABLE KEYS */;
INSERT INTO `almacen` (`id`, `direccion`, `telefono`, `latitud`, `longitud`, `foto`, `estado_sql`) VALUES
	(1, 'B. Salamanca', '66-65142', -24.66542, -64.2522, '1628519333_168c251121fbdff94d45.jpg', 1);
/*!40000 ALTER TABLE `almacen` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.anulacion
CREATE TABLE IF NOT EXISTS `anulacion` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `descripcion` tinytext NOT NULL,
  `id_factura` int(7) NOT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_anulacion_factura_venta` (`id_factura`),
  CONSTRAINT `FK_anulacion_factura_venta` FOREIGN KEY (`id_factura`) REFERENCES `factura_venta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.anulacion: ~0 rows (aproximadamente)
DELETE FROM `anulacion`;
/*!40000 ALTER TABLE `anulacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `anulacion` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.auxiliar
CREATE TABLE IF NOT EXISTS `auxiliar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `referencia` varchar(50) DEFAULT NULL,
  `valor` varchar(50) DEFAULT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.auxiliar: ~5 rows (aproximadamente)
DELETE FROM `auxiliar`;
/*!40000 ALTER TABLE `auxiliar` DISABLE KEYS */;
INSERT INTO `auxiliar` (`id`, `nombre`, `referencia`, `valor`, `descripcion`) VALUES
	(1, 'Restriccion Pedido', 'Tiempo (date)', '24', 'En horas'),
	(2, 'Debe', 'tipo_cuenta', 'D', 'Debe-Haber'),
	(3, 'Haber', 'tipo_cuenta', 'H', 'Haber-Debe'),
	(4, 'Grupo', 'grupo', 'G', 'Asociado a sub cuentas'),
	(5, 'Grupo', 'grupo', 'D', 'Detalle sin sub cuentas');
/*!40000 ALTER TABLE `auxiliar` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.categoria
CREATE TABLE IF NOT EXISTS `categoria` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `foto` varchar(200) DEFAULT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.categoria: ~2 rows (aproximadamente)
DELETE FROM `categoria`;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` (`id`, `nombre`, `descripcion`, `foto`, `estado_sql`) VALUES
	(4, 'Linea Blanca', 'Articulos electrodomesticos', 'astrid.png', 1),
	(5, 'Madera', 'Articulos a base de madera', 'bebidas.png', 1);
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.cliente
CREATE TABLE IF NOT EXISTS `cliente` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_persona` int(7) NOT NULL,
  `nit` varchar(12) NOT NULL,
  `razon_social` varchar(20) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  UNIQUE KEY `email` (`email`),
  KEY `FK_cliente_persona` (`id_persona`),
  CONSTRAINT `FK_cliente_persona` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.cliente: ~3 rows (aproximadamente)
DELETE FROM `cliente`;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` (`id`, `id_persona`, `nit`, `razon_social`, `usuario`, `contrasena`, `email`, `estado_sql`) VALUES
	(1, 2, '1337531', 'Torrejon', 'gabs', '$2y$10$3iomG9.AXSV5lU.V.atjxuMAoysMZufAFZslLNyuYDkSQyNa5KYDC', 'efra@gmail.com', 1),
	(2, 3, '7155658', 'OlwBlack', 'mayers', '$2y$10$3iomG9.AXSV5lU.V.atjxuMAoysMZufAFZslLNyuYDkSQyNa5KYDC', 'maye@outlook.com', 1),
	(4, 8, '7166845', 'Industrias Stark', '7166845', '$2y$10$9uV14t/LoLA1/HrtXIyCI.tWaI56LYK6gKH3lBcqIowEpnOysUDWC', NULL, 1);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.comprobante
CREATE TABLE IF NOT EXISTS `comprobante` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_factura` int(7) DEFAULT NULL,
  `tipo_respaldo` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `beneficiario` varchar(50) NOT NULL DEFAULT '',
  `glosa` varchar(50) NOT NULL DEFAULT '',
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.comprobante: ~0 rows (aproximadamente)
DELETE FROM `comprobante`;
/*!40000 ALTER TABLE `comprobante` DISABLE KEYS */;
/*!40000 ALTER TABLE `comprobante` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.detalle_compra
CREATE TABLE IF NOT EXISTS `detalle_compra` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_item` int(7) NOT NULL,
  `id_pedido_compra` int(7) NOT NULL,
  `cantidad` int(7) NOT NULL,
  `precio_unitario` varchar(8) NOT NULL,
  `total` varchar(8) NOT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_detalle_compra_item` (`id_item`),
  KEY `FK_detalle_compra_pedido_compra` (`id_pedido_compra`),
  CONSTRAINT `FK_detalle_compra_item` FOREIGN KEY (`id_item`) REFERENCES `item` (`id`),
  CONSTRAINT `FK_detalle_compra_pedido_compra` FOREIGN KEY (`id_pedido_compra`) REFERENCES `pedido_compra` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.detalle_compra: ~0 rows (aproximadamente)
DELETE FROM `detalle_compra`;
/*!40000 ALTER TABLE `detalle_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_compra` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.detalle_comprobante
CREATE TABLE IF NOT EXISTS `detalle_comprobante` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_comprobante` int(7) NOT NULL,
  `id_cuenta` int(7) NOT NULL,
  `debe` varchar(7) DEFAULT '0',
  `haber` varchar(7) DEFAULT '0',
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_detalle_comprobante_plan_cuenta` (`id_cuenta`),
  KEY `FK_detalle_comprobante_comprobante` (`id_comprobante`),
  CONSTRAINT `FK_detalle_comprobante_comprobante` FOREIGN KEY (`id_comprobante`) REFERENCES `comprobante` (`id`),
  CONSTRAINT `FK_detalle_comprobante_plan_cuenta` FOREIGN KEY (`id_cuenta`) REFERENCES `plan_cuenta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.detalle_comprobante: ~0 rows (aproximadamente)
DELETE FROM `detalle_comprobante`;
/*!40000 ALTER TABLE `detalle_comprobante` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_comprobante` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.detalle_venta
CREATE TABLE IF NOT EXISTS `detalle_venta` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_item` int(7) NOT NULL,
  `id_pedido_venta` int(7) NOT NULL,
  `cantidad` varchar(10) NOT NULL DEFAULT '0',
  `precio_unitario` varchar(10) NOT NULL,
  `descuento` int(2) NOT NULL DEFAULT '0',
  `total` int(10) NOT NULL DEFAULT '0',
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_detalle_venta_item` (`id_item`),
  KEY `FK_detalle_venta_pedido_venta` (`id_pedido_venta`),
  CONSTRAINT `FK_detalle_venta_item` FOREIGN KEY (`id_item`) REFERENCES `item` (`id`),
  CONSTRAINT `FK_detalle_venta_pedido_venta` FOREIGN KEY (`id_pedido_venta`) REFERENCES `pedido_venta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.detalle_venta: ~7 rows (aproximadamente)
DELETE FROM `detalle_venta`;
/*!40000 ALTER TABLE `detalle_venta` DISABLE KEYS */;
INSERT INTO `detalle_venta` (`id`, `id_item`, `id_pedido_venta`, `cantidad`, `precio_unitario`, `descuento`, `total`, `estado_sql`) VALUES
	(1, 8, 2, '1', '850', 0, 850, 1),
	(2, 9, 2, '1', '950', 0, 950, 1),
	(3, 9, 3, '2', '1900', 0, 1900, 1),
	(4, 8, 4, '1', '850', 0, 850, 1),
	(5, 8, 5, '1', '850', 0, 850, 1),
	(7, 8, 29, '2', '850', 0, 1700, 1),
	(8, 9, 29, '1', '950', 0, 950, 1);
/*!40000 ALTER TABLE `detalle_venta` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.empleado
CREATE TABLE IF NOT EXISTS `empleado` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_persona` int(7) NOT NULL,
  `id_almacen` int(7) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `caja` varchar(20) DEFAULT NULL,
  `fecha_ingreso` date NOT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  UNIQUE KEY `email` (`email`),
  KEY `FK_empleado_persona` (`id_persona`),
  KEY `FK_empleado_almacen` (`id_almacen`),
  CONSTRAINT `FK_empleado_almacen` FOREIGN KEY (`id_almacen`) REFERENCES `almacen` (`id`),
  CONSTRAINT `FK_empleado_persona` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.empleado: ~4 rows (aproximadamente)
DELETE FROM `empleado`;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` (`id`, `id_persona`, `id_almacen`, `usuario`, `contrasena`, `email`, `caja`, `fecha_ingreso`, `estado_sql`) VALUES
	(2, 1, 1, 'gabozki', '$2y$10$3iomG9.AXSV5lU.V.atjxuMAoysMZufAFZslLNyuYDkSQyNa5KYDC', 'gabo@gmail.com', NULL, '2021-08-09', 1),
	(3, 4, 1, 'belents', '$2y$10$3iomG9.AXSV5lU.V.atjxuMAoysMZufAFZslLNyuYDkSQyNa5KYDC', 'belen@gmail.com', 'Caja 1', '2021-09-13', 1),
	(4, 5, 1, 'winny', '$2y$10$3iomG9.AXSV5lU.V.atjxuMAoysMZufAFZslLNyuYDkSQyNa5KYDC', 'win@anime.flv', '', '2021-09-15', 1),
	(5, 6, 1, 'al23', '$2y$10$3iomG9.AXSV5lU.V.atjxuMAoysMZufAFZslLNyuYDkSQyNa5KYDC', 'alfons@anime.flv', 'Caja General', '2021-09-18', 1);
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.empleado_rol
CREATE TABLE IF NOT EXISTS `empleado_rol` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(7) NOT NULL,
  `id_rol` int(7) NOT NULL,
  `horario` varchar(50) DEFAULT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK__empleado` (`id_empleado`),
  KEY `FK_empleado_rol_rol` (`id_rol`),
  CONSTRAINT `FK__empleado` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`),
  CONSTRAINT `FK_empleado_rol_rol` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.empleado_rol: ~5 rows (aproximadamente)
DELETE FROM `empleado_rol`;
/*!40000 ALTER TABLE `empleado_rol` DISABLE KEYS */;
INSERT INTO `empleado_rol` (`id`, `id_empleado`, `id_rol`, `horario`, `estado_sql`) VALUES
	(1, 2, 1, NULL, 1),
	(2, 3, 2, NULL, 1),
	(3, 3, 3, NULL, 1),
	(4, 4, 4, NULL, 1),
	(5, 5, 5, NULL, 1);
/*!40000 ALTER TABLE `empleado_rol` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.factura_compra
CREATE TABLE IF NOT EXISTS `factura_compra` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_comprobante` int(7) NOT NULL,
  `id_pedido_compra` int(7) NOT NULL,
  `total` varchar(10) NOT NULL DEFAULT '0',
  `nro_factura` varchar(15) NOT NULL,
  `fecha` date NOT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_factura_compra_pedido_compra` (`id_pedido_compra`),
  CONSTRAINT `FK_factura_compra_pedido_compra` FOREIGN KEY (`id_pedido_compra`) REFERENCES `pedido_compra` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.factura_compra: ~0 rows (aproximadamente)
DELETE FROM `factura_compra`;
/*!40000 ALTER TABLE `factura_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_compra` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.factura_venta
CREATE TABLE IF NOT EXISTS `factura_venta` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_comprobante` int(7) DEFAULT NULL,
  `id_pedido_venta` int(7) NOT NULL,
  `nit_empresa` varchar(20) NOT NULL,
  `nro_factura` varchar(25) NOT NULL,
  `autorizacion` varchar(25) NOT NULL,
  `fecha_emision` date NOT NULL,
  `nit_cliente` varchar(20) NOT NULL,
  `beneficiario` varchar(30) NOT NULL,
  `total` varchar(10) NOT NULL,
  `codigo_control` varchar(10) NOT NULL,
  `fecha_limite` date NOT NULL,
  `codigo_qr` varchar(500) NOT NULL,
  `observaciones` varchar(500) NOT NULL,
  `estado_sql` int(7) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_factura_venta_pedido_venta` (`id_pedido_venta`),
  CONSTRAINT `FK_factura_venta_pedido_venta` FOREIGN KEY (`id_pedido_venta`) REFERENCES `pedido_venta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.factura_venta: ~0 rows (aproximadamente)
DELETE FROM `factura_venta`;
/*!40000 ALTER TABLE `factura_venta` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_venta` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.generales
CREATE TABLE IF NOT EXISTS `generales` (
  `nit_empresa` varchar(20) DEFAULT NULL,
  `nombre_empresa` varchar(30) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `contacto` varchar(50) DEFAULT NULL,
  `logo` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.generales: ~1 rows (aproximadamente)
DELETE FROM `generales`;
/*!40000 ALTER TABLE `generales` DISABLE KEYS */;
INSERT INTO `generales` (`nit_empresa`, `nombre_empresa`, `direccion`, `contacto`, `logo`) VALUES
	('1337531', 'Megabe', 'B. Salamanca', 'Gabriel Torrejon', '1');
/*!40000 ALTER TABLE `generales` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.item
CREATE TABLE IF NOT EXISTS `item` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `id_marca` int(7) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `codigo` varchar(15) NOT NULL,
  `stock` varchar(10) NOT NULL,
  `precio_unitario` varchar(10) NOT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_item_marca` (`id_marca`),
  CONSTRAINT `FK_item_marca` FOREIGN KEY (`id_marca`) REFERENCES `marca` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.item: ~2 rows (aproximadamente)
DELETE FROM `item`;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` (`id`, `nombre`, `id_marca`, `descripcion`, `codigo`, `stock`, `precio_unitario`, `foto`, `estado_sql`) VALUES
	(8, 'Refrigerador LG no frost 690Lts', 1, 'InstaView Door-in-Door Silver inverter', 'LS74SXSX', '25', '850', '1631059405_952d29e36f44b5a68f83.png', 1),
	(9, 'Cocina a gas', 2, 'Estufa a gas con Diseño Deslizable', 'NX60T8755SS/AP', '20', '950', 'cocina.png', 1);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.item_almacen
CREATE TABLE IF NOT EXISTS `item_almacen` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_almacen` int(7) NOT NULL,
  `id_item` int(7) NOT NULL,
  `stock` varchar(8) NOT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_item_almacen_almacen` (`id_almacen`),
  KEY `FK_item_almacen_item` (`id_item`),
  CONSTRAINT `FK_item_almacen_almacen` FOREIGN KEY (`id_almacen`) REFERENCES `almacen` (`id`),
  CONSTRAINT `FK_item_almacen_item` FOREIGN KEY (`id_item`) REFERENCES `item` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.item_almacen: ~2 rows (aproximadamente)
DELETE FROM `item_almacen`;
/*!40000 ALTER TABLE `item_almacen` DISABLE KEYS */;
INSERT INTO `item_almacen` (`id`, `id_almacen`, `id_item`, `stock`, `estado_sql`) VALUES
	(1, 1, 8, '25', 1),
	(2, 1, 9, '20', 1);
/*!40000 ALTER TABLE `item_almacen` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.item_promo
CREATE TABLE IF NOT EXISTS `item_promo` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_item` int(7) NOT NULL,
  `id_promocion` int(7) NOT NULL,
  `descripcion` text NOT NULL,
  `nuevo_precio` int(8) NOT NULL DEFAULT '0',
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_item_promo_item` (`id_item`),
  KEY `FK_item_promo_promocion` (`id_promocion`),
  CONSTRAINT `FK_item_promo_item` FOREIGN KEY (`id_item`) REFERENCES `item` (`id`),
  CONSTRAINT `FK_item_promo_promocion` FOREIGN KEY (`id_promocion`) REFERENCES `promocion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.item_promo: ~1 rows (aproximadamente)
DELETE FROM `item_promo`;
/*!40000 ALTER TABLE `item_promo` DISABLE KEYS */;
INSERT INTO `item_promo` (`id`, `id_item`, `id_promocion`, `descripcion`, `nuevo_precio`, `estado_sql`) VALUES
	(1, 9, 1, '20% descuento por Navidad', 760, 1);
/*!40000 ALTER TABLE `item_promo` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.marca
CREATE TABLE IF NOT EXISTS `marca` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `id_subcategoria` int(7) NOT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_marca_subcategoria` (`id_subcategoria`),
  CONSTRAINT `FK_marca_subcategoria` FOREIGN KEY (`id_subcategoria`) REFERENCES `subcategoria` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.marca: ~3 rows (aproximadamente)
DELETE FROM `marca`;
/*!40000 ALTER TABLE `marca` DISABLE KEYS */;
INSERT INTO `marca` (`id`, `nombre`, `descripcion`, `id_subcategoria`, `estado_sql`) VALUES
	(1, 'LG', 'Marca Japonesa de gran prestigio', 4, 1),
	(2, 'Samsung', 'Marca Japonesa con gran trayectoria', 4, 1),
	(3, 'JK', 'Lubricantes', 6, 1);
/*!40000 ALTER TABLE `marca` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.pedido_compra
CREATE TABLE IF NOT EXISTS `pedido_compra` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(7) NOT NULL,
  `id_proveedor` int(7) NOT NULL,
  `moneda` varchar(20) NOT NULL DEFAULT 'Bs',
  `tipo_pago` varchar(20) NOT NULL DEFAULT 'deposito',
  `estado` varchar(20) NOT NULL,
  `fecha` date NOT NULL,
  `total` int(8) NOT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_pedido_compra_empleado` (`id_empleado`),
  KEY `FK_pedido_compra_proveedor` (`id_proveedor`),
  CONSTRAINT `FK_pedido_compra_empleado` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`),
  CONSTRAINT `FK_pedido_compra_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.pedido_compra: ~0 rows (aproximadamente)
DELETE FROM `pedido_compra`;
/*!40000 ALTER TABLE `pedido_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedido_compra` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.pedido_venta
CREATE TABLE IF NOT EXISTS `pedido_venta` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(7) DEFAULT NULL,
  `id_cliente` int(7) DEFAULT NULL,
  `estado` varchar(1) NOT NULL,
  `moneda` varchar(20) NOT NULL DEFAULT 'Bs',
  `tipo_pago` varchar(20) NOT NULL DEFAULT 'deposito',
  `fecha` datetime NOT NULL,
  `total` varchar(50) NOT NULL DEFAULT '0',
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_pedido_venta_empleado` (`id_empleado`),
  KEY `FK_pedido_venta_cliente` (`id_cliente`),
  CONSTRAINT `FK_pedido_venta_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`),
  CONSTRAINT `FK_pedido_venta_empleado` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.pedido_venta: ~5 rows (aproximadamente)
DELETE FROM `pedido_venta`;
/*!40000 ALTER TABLE `pedido_venta` DISABLE KEYS */;
INSERT INTO `pedido_venta` (`id`, `id_empleado`, `id_cliente`, `estado`, `moneda`, `tipo_pago`, `fecha`, `total`, `estado_sql`) VALUES
	(2, 2, 1, '1', 'Bs', 'deposito', '2021-09-08 08:08:12', '1800', 1),
	(3, 2, 1, '0', 'Bs', 'deposito', '2021-08-06 09:55:57', '1900', 1),
	(4, 2, 2, '0', 'Bs', 'deposito', '2021-07-15 09:58:03', '850', 1),
	(5, 3, 2, '1', 'Bs', 'deposito', '2021-09-22 11:16:06', '850', 1),
	(29, 3, 4, '1', 'Bs', 'deposito', '2021-09-22 20:34:43', '2650', 1);
/*!40000 ALTER TABLE `pedido_venta` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.persona
CREATE TABLE IF NOT EXISTS `persona` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) NOT NULL,
  `apellido_paterno` varchar(20) NOT NULL,
  `apellido_materno` varchar(20) DEFAULT NULL,
  `nro_ci` varchar(10) NOT NULL,
  `direccion_particular` varchar(100) DEFAULT NULL,
  `direccion_trabajo` varchar(100) DEFAULT 'NO ESPECIFICADO',
  `telefono_particular` varchar(10) DEFAULT NULL,
  `telefono_trabajo` varchar(10) DEFAULT NULL,
  `zona_vivienda` varchar(10) DEFAULT NULL,
  `latitud_vivienda` varchar(15) DEFAULT 'NO ESPECIFICADO',
  `longitud_vivienda` varchar(15) DEFAULT 'NO ESPECIFICADO',
  `celular1` varchar(8) DEFAULT NULL,
  `celular2` varchar(8) DEFAULT NULL,
  `lugar_residencia` varchar(20) DEFAULT NULL,
  `ocupacion` varchar(50) DEFAULT NULL,
  `foto` varchar(100) DEFAULT '',
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nro_ci` (`nro_ci`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.persona: ~7 rows (aproximadamente)
DELETE FROM `persona`;
/*!40000 ALTER TABLE `persona` DISABLE KEYS */;
INSERT INTO `persona` (`id`, `nombre`, `apellido_paterno`, `apellido_materno`, `nro_ci`, `direccion_particular`, `direccion_trabajo`, `telefono_particular`, `telefono_trabajo`, `zona_vivienda`, `latitud_vivienda`, `longitud_vivienda`, `celular1`, `celular2`, `lugar_residencia`, `ocupacion`, `foto`, `estado_sql`) VALUES
	(1, 'Gabriel', 'Torrejon', 'Sejas', '7168454', 'B. Salamanca', 'Av. Colon', '66-37217', '', '2', NULL, NULL, '65810249', NULL, 'Casa', 'Estudiante', 'eren.png', 1),
	(2, 'Efrain', 'Tejerina', NULL, '1337531', 'B. Las Panosas', 'NO ESPECIFICADO', NULL, NULL, NULL, 'NO ESPECIFICADO', 'NO ESPECIFICADO', '72954724', NULL, NULL, NULL, '1632175128_34077a8c01750c79cc17.png', 1),
	(3, 'Mayer', 'Sejas', 'Rivero', '16687523', 'B.Juan XXIII', 'NO ESPECIFICADO', '66-65825', NULL, NULL, 'NO ESPECIFICADO', 'NO ESPECIFICADO', '72960906', NULL, NULL, NULL, '', 1),
	(4, 'Belen', 'Torrejon', 'Sejas', '7168455', 'B. Luis de Fuentes', 'NO ESPECIFICADO', '66-35815', NULL, NULL, 'NO ESPECIFICADO', 'NO ESPECIFICADO', '65820452', NULL, NULL, NULL, '', 1),
	(5, 'Winry', 'Eldric', NULL, '746213', 'B. Miraflores', 'NO ESPECIFICADO', '66-57413', NULL, NULL, 'NO ESPECIFICADO', 'NO ESPECIFICADO', '72954475', NULL, NULL, 'Ing. Mecanica', '', 1),
	(6, 'Alfons', 'Porta', NULL, '1132456', 'B. 14 viviendas', 'NO ESPECIFICADO', '66-33714', NULL, NULL, 'NO ESPECIFICADO', 'NO ESPECIFICADO', '67442056', NULL, NULL, NULL, '', 1),
	(8, 'Tony', 'Stark', NULL, '7166845', NULL, 'NO ESPECIFICADO', NULL, NULL, NULL, 'NO ESPECIFICADO', 'NO ESPECIFICADO', NULL, NULL, NULL, NULL, '', 1);
/*!40000 ALTER TABLE `persona` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.plan_cuenta
CREATE TABLE IF NOT EXISTS `plan_cuenta` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `codigo_cuenta` varchar(50) NOT NULL,
  `nombre_cuenta` varchar(50) NOT NULL,
  `tipo_cuenta` varchar(20) NOT NULL,
  `grupo` varchar(20) NOT NULL,
  `id_cuenta_padre` int(7) DEFAULT NULL,
  `debe` int(7) DEFAULT NULL,
  `haber` int(7) DEFAULT NULL,
  `saldo` int(7) DEFAULT NULL,
  `estado_sql` int(7) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_plan_cuenta_plan_cuenta` (`id_cuenta_padre`),
  CONSTRAINT `FK_plan_cuenta_plan_cuenta` FOREIGN KEY (`id_cuenta_padre`) REFERENCES `plan_cuenta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.plan_cuenta: ~14 rows (aproximadamente)
DELETE FROM `plan_cuenta`;
/*!40000 ALTER TABLE `plan_cuenta` DISABLE KEYS */;
INSERT INTO `plan_cuenta` (`id`, `codigo_cuenta`, `nombre_cuenta`, `tipo_cuenta`, `grupo`, `id_cuenta_padre`, `debe`, `haber`, `saldo`, `estado_sql`) VALUES
	(1, '1', 'Activo o derecho', 'D', 'G', NULL, NULL, NULL, NULL, 1),
	(2, '11', 'Activo corriente', 'D', 'G', 1, NULL, NULL, NULL, 1),
	(3, '111', 'Disponible', 'D', 'G', 2, NULL, NULL, NULL, 1),
	(4, '11101', 'Caja Moneda Nacional', 'D', 'G', 3, NULL, NULL, NULL, 1),
	(5, '1110101', 'Caja 1', 'D', 'D', 4, NULL, NULL, NULL, 1),
	(6, '11103', 'Banco Moneda Nacional', 'D', 'G', 3, NULL, NULL, NULL, 1),
	(7, '1110301', 'Banco Nacional de Bolivia', 'D', 'D', 6, NULL, NULL, NULL, 1),
	(8, '1110302', 'Banco Union', 'D', 'D', 6, NULL, NULL, NULL, 1),
	(9, '1110302', 'Banco Bisa', 'D', 'D', 6, NULL, NULL, NULL, 1),
	(10, '1110102', 'Caja 2', 'D', 'D', 4, NULL, NULL, NULL, 1),
	(11, '113', 'Bienes de Cambio o Realizable', 'D', 'G', 2, NULL, NULL, NULL, 1),
	(12, '11301', 'Existencias de Mercaderias', 'D', 'G', 11, NULL, NULL, NULL, 1),
	(13, '1130101', 'Mercaderia en Almacen', 'D', 'D', 12, NULL, NULL, NULL, 1),
	(14, '1110199', 'Caja General', 'D', 'D', 4, NULL, NULL, NULL, 1);
/*!40000 ALTER TABLE `plan_cuenta` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.promocion
CREATE TABLE IF NOT EXISTS `promocion` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `descuento` int(2) NOT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.promocion: ~1 rows (aproximadamente)
DELETE FROM `promocion`;
/*!40000 ALTER TABLE `promocion` DISABLE KEYS */;
INSERT INTO `promocion` (`id`, `nombre`, `codigo`, `fecha_inicio`, `fecha_fin`, `descuento`, `estado_sql`) VALUES
	(1, 'Navidad', 'LS123', '2021-09-14', '2022-01-14', 20, 1);
/*!40000 ALTER TABLE `promocion` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.proveedor
CREATE TABLE IF NOT EXISTS `proveedor` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_persona` int(7) NOT NULL,
  `nit` varchar(15) NOT NULL,
  `razon_social` varchar(50) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `contrasena` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_proveedor_persona` (`id_persona`),
  CONSTRAINT `FK_proveedor_persona` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.proveedor: ~0 rows (aproximadamente)
DELETE FROM `proveedor`;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.rol
CREATE TABLE IF NOT EXISTS `rol` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.rol: ~5 rows (aproximadamente)
DELETE FROM `rol`;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` (`id`, `nombre`, `descripcion`, `estado_sql`) VALUES
	(1, 'Administrador', 'Jefe', 1),
	(2, 'Vendedor', 'Armar y confirmar pedido, confirma paga en linea', 1),
	(3, 'Cajero', 'Recibe dinero fisico', 1),
	(4, 'Almacenes', 'Entregas e inventario', 1),
	(5, 'Contador', 'Contabilidad', 1);
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.subcategoria
CREATE TABLE IF NOT EXISTS `subcategoria` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_categoria` int(7) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `descripcion` varchar(150) NOT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_subcategoria_categoria` (`id_categoria`),
  CONSTRAINT `FK_subcategoria_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.subcategoria: ~3 rows (aproximadamente)
DELETE FROM `subcategoria`;
/*!40000 ALTER TABLE `subcategoria` DISABLE KEYS */;
INSERT INTO `subcategoria` (`id`, `id_categoria`, `nombre`, `descripcion`, `foto`, `estado_sql`) VALUES
	(4, 4, 'Cocina', 'Articulos para la cocina', 'astrid.png', 1),
	(5, 4, 'Baño', 'Articulos para el baño', 'carnes.png', 1),
	(6, 5, 'Lubricantes', 'Articulos para lubricar madera', 'bebidas.png', 1);
/*!40000 ALTER TABLE `subcategoria` ENABLE KEYS */;

-- Volcando estructura para tabla megabe.transferencia
CREATE TABLE IF NOT EXISTS `transferencia` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_almacen_origen` int(7) NOT NULL,
  `id_almacen_destino` int(7) NOT NULL,
  `id_empleado1` int(7) NOT NULL,
  `id_empleado2` int(7) NOT NULL,
  `fecha_envio` date NOT NULL,
  `fecha_recibido` date NOT NULL,
  `estado_sql` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_transferencia_almacen` (`id_almacen_origen`),
  KEY `FK_transferencia_almacen_2` (`id_almacen_destino`),
  KEY `FK_transferencia_empleado` (`id_empleado1`),
  KEY `FK_transferencia_empleado_2` (`id_empleado2`),
  CONSTRAINT `FK_transferencia_almacen` FOREIGN KEY (`id_almacen_origen`) REFERENCES `almacen` (`id`),
  CONSTRAINT `FK_transferencia_almacen_2` FOREIGN KEY (`id_almacen_destino`) REFERENCES `almacen` (`id`),
  CONSTRAINT `FK_transferencia_empleado` FOREIGN KEY (`id_empleado1`) REFERENCES `empleado` (`id`),
  CONSTRAINT `FK_transferencia_empleado_2` FOREIGN KEY (`id_empleado2`) REFERENCES `empleado` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla megabe.transferencia: ~0 rows (aproximadamente)
DELETE FROM `transferencia`;
/*!40000 ALTER TABLE `transferencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `transferencia` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
